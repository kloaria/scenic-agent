import os
import httpx

from datetime import date as Date
from datetime import datetime, timedelta, timezone

from fastapi import FastAPI, HTTPException, Query


# ============================================================
# FastAPI
# ============================================================

app = FastAPI(
    title="陈家祠实时服务 API",
    description="提供陈家祠天气查询和开放状态查询服务",
    version="1.1.0"
)


# ============================================================
# 基础配置
# ============================================================

# 高德 Web 服务 Key
# 本地通过环境变量设置；Render 中通过 Environment Variables 设置
AMAP_KEY = os.getenv("AMAP_KEY")

# 广州市行政区划代码
GUANGZHOU_ADCODE = "440100"

# 中国标准时间 UTC+8
CHINA_TZ = timezone(timedelta(hours=8))


# ============================================================
# 陈家祠开放规则
# ============================================================

# Python weekday()：
# 周一 = 0，周二 = 1，周三 = 2，周四 = 3，周五 = 4，周六 = 5，周日 = 6
REGULAR_CLOSED_WEEKDAY = 1  # 每周二固定闭馆

# 常规开放时间
OPENING_TIME = "09:00"
LAST_ENTRY_TIME = "17:00"
CLOSING_TIME = "17:30"


# ============================================================
# 特殊开放 / 特殊闭馆日期
# ============================================================

# 临时或特殊开放日期。优先级高于法定节假日规则和周二闭馆规则。
# 示例：SPECIAL_OPEN_DATES = {"2026-12-29"}
SPECIAL_OPEN_DATES = set()

# 临时闭馆日期。优先级最高，即使当天是法定节假日也以临时闭馆为准。
# 示例：SPECIAL_CLOSED_DATES = {"2026-09-10"}
SPECIAL_CLOSED_DATES = set()


# ============================================================
# 2026 年法定节假日放假日期
# 规则：陈家祠“每周二闭馆，法定节假日除外”
# 因此这些日期如果刚好是周二，也应按开放日处理。
# ============================================================

STATUTORY_HOLIDAY_PERIODS_2026 = {
    "元旦": ("2026-01-01", "2026-01-03"),
    "春节": ("2026-02-15", "2026-02-23"),
    "清明节": ("2026-04-04", "2026-04-06"),
    "劳动节": ("2026-05-01", "2026-05-05"),
    "端午节": ("2026-06-19", "2026-06-21"),
    "中秋节": ("2026-09-25", "2026-09-27"),
    "国庆节": ("2026-10-01", "2026-10-07"),
}


def get_statutory_holiday_name(target_date: Date):
    """如果目标日期属于已维护的法定节假日放假区间，返回节日名称，否则返回 None。"""
    for holiday_name, (start_str, end_str) in STATUTORY_HOLIDAY_PERIODS_2026.items():
        start_date = Date.fromisoformat(start_str)
        end_date = Date.fromisoformat(end_str)
        if start_date <= target_date <= end_date:
            return holiday_name
    return None


# ============================================================
# 首页
# ============================================================

@app.get("/")
def root():
    return {
        "status": "ok",
        "service": "Chenjiaci Realtime Service API",
        "available_tools": [
            "/weather",
            "/opening-info"
        ]
    }


# ============================================================
# 日期解析
# ============================================================

def resolve_visit_date(value: str) -> Date:
    """
    将用户传入的日期参数转换为实际日期。

    支持：
    - today / 今天
    - tomorrow / 明天
    - day_after_tomorrow / 后天
    - YYYY-MM-DD
    """
    today = datetime.now(CHINA_TZ).date()
    value = value.strip().lower()

    if value in ["today", "今天"]:
        return today

    if value in ["tomorrow", "明天"]:
        return today + timedelta(days=1)

    if value in ["day_after_tomorrow", "后天"]:
        return today + timedelta(days=2)

    try:
        return Date.fromisoformat(value)
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=(
                "date 格式错误。"
                "请使用 today、tomorrow、day_after_tomorrow "
                "或 YYYY-MM-DD。"
            )
        )


# ============================================================
# 开放状态查询
# ============================================================

@app.get("/opening-info")
def get_opening_info(
    date: str = Query(
        default="today",
        description=(
            "要查询的参观日期。"
            "支持 today、tomorrow、day_after_tomorrow "
            "或 YYYY-MM-DD。"
        )
    )
):
    target_date = resolve_visit_date(date)
    target_date_str = target_date.isoformat()
    weekday_number = target_date.weekday()

    weekday_names = [
        "周一", "周二", "周三", "周四", "周五", "周六", "周日"
    ]
    weekday_zh = weekday_names[weekday_number]

    holiday_name = get_statutory_holiday_name(target_date)
    is_statutory_holiday = holiday_name is not None

    # --------------------------------------------------------
    # 规则优先级：
    # 1. 临时/特殊闭馆
    # 2. 特殊开放
    # 3. 法定节假日例外（覆盖“周二闭馆”）
    # 4. 每周二固定闭馆
    # 5. 常规开放
    # --------------------------------------------------------

    # 1. 特殊闭馆：优先级最高
    if target_date_str in SPECIAL_CLOSED_DATES:
        return {
            "success": True,
            "target_date": target_date_str,
            "weekday": weekday_zh,
            "is_open": False,
            "status": "closed",
            "reason": "特殊闭馆安排",
            "opening_time": None,
            "last_entry_time": None,
            "closing_time": None,
            "regular_closed_weekday": "周二",
            "is_statutory_holiday": is_statutory_holiday,
            "holiday_name": holiday_name,
            "rule_type": "special_closed",
            "rule_priority": 1,
            "realtime": False,
            "source": "陈家祠参观规则（当前维护数据）",
            "notice": "特殊及临时开放安排请以官方最新公告为准。"
        }

    # 2. 特殊开放
    if target_date_str in SPECIAL_OPEN_DATES:
        return {
            "success": True,
            "target_date": target_date_str,
            "weekday": weekday_zh,
            "is_open": True,
            "status": "open",
            "reason": "特殊开放安排",
            "opening_time": OPENING_TIME,
            "last_entry_time": LAST_ENTRY_TIME,
            "closing_time": CLOSING_TIME,
            "regular_closed_weekday": "周二",
            "is_statutory_holiday": is_statutory_holiday,
            "holiday_name": holiday_name,
            "rule_type": "special_open",
            "rule_priority": 2,
            "realtime": False,
            "source": "陈家祠参观规则（当前维护数据）",
            "notice": "特殊及临时开放安排请以官方最新公告为准。"
        }

    # 3. 法定节假日例外：覆盖“每周二闭馆”
    if is_statutory_holiday:
        return {
            "success": True,
            "target_date": target_date_str,
            "weekday": weekday_zh,
            "is_open": True,
            "status": "open",
            "reason": f"{holiday_name}法定节假日，适用‘每周二闭馆，法定节假日除外’规则",
            "opening_time": OPENING_TIME,
            "last_entry_time": LAST_ENTRY_TIME,
            "closing_time": CLOSING_TIME,
            "regular_closed_weekday": "周二",
            "is_statutory_holiday": True,
            "holiday_name": holiday_name,
            "rule_type": "statutory_holiday_exception",
            "rule_priority": 3,
            "realtime": False,
            "source": "陈家祠参观规则（当前维护数据）",
            "notice": "如有临时闭馆或特殊调整，请以陈家祠官方最新公告为准。"
        }

    # 4. 每周二固定闭馆
    if weekday_number == REGULAR_CLOSED_WEEKDAY:
        return {
            "success": True,
            "target_date": target_date_str,
            "weekday": weekday_zh,
            "is_open": False,
            "status": "closed",
            "reason": "固定闭馆日（每周二，法定节假日除外）",
            "opening_time": None,
            "last_entry_time": None,
            "closing_time": None,
            "regular_closed_weekday": "周二",
            "is_statutory_holiday": False,
            "holiday_name": None,
            "rule_type": "regular_tuesday_closed",
            "rule_priority": 4,
            "realtime": False,
            "source": "陈家祠参观规则（当前维护数据）",
            "notice": "节假日或临时开放安排请以官方最新公告为准。"
        }

    # 5. 常规开放日
    return {
        "success": True,
        "target_date": target_date_str,
        "weekday": weekday_zh,
        "is_open": True,
        "status": "open",
        "reason": "按照当前常规参观规则，该日正常开放",
        "opening_time": OPENING_TIME,
        "last_entry_time": LAST_ENTRY_TIME,
        "closing_time": CLOSING_TIME,
        "regular_closed_weekday": "周二",
        "is_statutory_holiday": False,
        "holiday_name": None,
        "rule_type": "regular_open",
        "rule_priority": 5,
        "realtime": False,
        "source": "陈家祠参观规则（当前维护数据）",
        "notice": "实际开放情况可能因节假日、维护或临时活动调整，请以官方最新公告为准。"
    }


# ============================================================
# 天气查询
# ============================================================

@app.get("/weather")
async def get_weather(
    query_type: str = Query(
        default="current",
        description=(
            "天气查询类型："
            "current 查询实时天气；"
            "forecast 查询未来天气预报。"
        )
    )
):

    # --------------------------------------------------------
    # 1. 检查高德 Key
    # --------------------------------------------------------

    if not AMAP_KEY:
        raise HTTPException(
            status_code=500,
            detail="AMAP_KEY 未配置"
        )


    # --------------------------------------------------------
    # 2. 检查查询类型
    # --------------------------------------------------------

    if query_type not in ["current", "forecast"]:
        raise HTTPException(
            status_code=400,
            detail="query_type 只能是 current 或 forecast"
        )


    # 高德天气 API
    # base = 实时天气
    # all  = 天气预报
    extensions = (
        "base"
        if query_type == "current"
        else "all"
    )

    url = (
        "https://restapi.amap.com/"
        "v3/weather/weatherInfo"
    )

    params = {
        "key": AMAP_KEY,
        "city": GUANGZHOU_ADCODE,
        "extensions": extensions,
        "output": "JSON"
    }


    # --------------------------------------------------------
    # 3. 调用高德天气 API
    # --------------------------------------------------------

    try:

        async with httpx.AsyncClient(
            timeout=10.0
        ) as client:

            response = await client.get(
                url,
                params=params
            )

            response.raise_for_status()

        data = response.json()


    except httpx.TimeoutException:

        raise HTTPException(
            status_code=504,
            detail="天气服务请求超时"
        )


    except httpx.HTTPError as e:

        raise HTTPException(
            status_code=502,
            detail=f"天气服务请求失败：{str(e)}"
        )


    # --------------------------------------------------------
    # 4. 高德接口业务错误
    # --------------------------------------------------------

    if data.get("status") != "1":

        raise HTTPException(
            status_code=502,
            detail={
                "message": "高德天气接口返回错误",
                "info": data.get("info"),
                "infocode": data.get("infocode")
            }
        )


    # ========================================================
    # 实时天气 current
    # ========================================================

    if query_type == "current":

        lives = data.get("lives", [])

        if not lives:
            raise HTTPException(
                status_code=502,
                detail="没有获取到实时天气"
            )

        live = lives[0]

        return {
            "success": True,

            "type": "current",

            "scenic_spot": "陈家祠",

            "province": live.get("province"),
            "city": live.get("city"),

            "weather": live.get("weather"),

            "temperature": live.get(
                "temperature"
            ),

            "humidity": live.get(
                "humidity"
            ),

            "wind_direction": live.get(
                "winddirection"
            ),

            "wind_power": live.get(
                "windpower"
            ),

            "report_time": live.get(
                "reporttime"
            ),

            "source": "高德开放平台天气服务"
        }


    # ========================================================
    # 天气预报 forecast
    # ========================================================

    forecasts = data.get("forecasts", [])

    if not forecasts:
        raise HTTPException(
            status_code=502,
            detail="没有获取到天气预报"
        )

    forecast = forecasts[0]

    # 把高德返回的数据稍微整理一下，
    # 方便 Dify Agent 使用。
    result = []

    for item in forecast.get("casts", []):

        result.append({
            "date": item.get("date"),

            "week": item.get("week"),

            "day_weather": item.get(
                "dayweather"
            ),

            "night_weather": item.get(
                "nightweather"
            ),

            "day_temperature": item.get(
                "daytemp"
            ),

            "night_temperature": item.get(
                "nighttemp"
            ),

            "day_wind": item.get(
                "daywind"
            ),

            "night_wind": item.get(
                "nightwind"
            ),

            "day_wind_power": item.get(
                "daypower"
            ),

            "night_wind_power": item.get(
                "nightpower"
            )
        })


    return {
        "success": True,

        "type": "forecast",

        "scenic_spot": "陈家祠",

        "province": forecast.get(
            "province"
        ),

        "city": forecast.get(
            "city"
        ),

        "report_time": forecast.get(
            "reporttime"
        ),

        "forecast": result,

        "source": "高德开放平台天气服务"
    }